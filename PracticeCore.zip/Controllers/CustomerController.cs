﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PracticeCore.Models;
using PracticeCore.Models.Repository;

namespace PracticeCore.Controllers
{
    [Route("api/customer")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerRepository<Customer> _customerRepository;
        public CustomerController(ICustomerRepository<Customer> customerRepository)
        {
            _customerRepository = customerRepository;
        }

        //api/customer
        [HttpGet]
        public async Task<IActionResult> GetAllCustomers()
        {
            IEnumerable<Customer> customers = await _customerRepository.GetAllCustomers();
            if (customers == null)
            {
                return NotFound("The Customer record couldn't be found.");
            }
            return Ok(customers);
        }

        //api/customer/1
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCustomer(long customerId)
        {
            Customer customer = await _customerRepository.GetCustomer(customerId);
            return Ok(customer);
        }

        //api/customer/
        [HttpPost]
        public async Task<IActionResult> AddCustomer([FromBody]Customer customer)
        {
            if (customer == null)
                return BadRequest("Send valid data");
            await _customerRepository.AddCustomer(customer);
            return CreatedAtRoute("GetCustomer", new { Id = customer.CustomerId }, customer);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCustomer(long customerId, [FromBody]Customer customer)
        {
            if (customer == null)
                return BadRequest("Send valid data");
            Customer fetchCustomer = await _customerRepository.GetCustomer(customerId);
            if (fetchCustomer == null)
                return BadRequest("Customer not found");
            await _customerRepository.UpdateCustomer(fetchCustomer, customer);
            return NoContent();
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteCustomer(long customerId)
        {
            Customer fetchCustomer = await _customerRepository.GetCustomer(customerId);
            if (fetchCustomer == null)
                return BadRequest("Customer not found");

            await _customerRepository.DeleteCustomer(fetchCustomer);
            return NoContent();
        }
    }
}