﻿using Microsoft.EntityFrameworkCore;
using PracticeCore.Models.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PracticeCore.Models.DataManager
{
    public class CustomerManager : ICustomerRepository<Customer>
    {
        readonly PracticeCoreContext _pcContext;
        public CustomerManager(PracticeCoreContext pcContext)
        {
            _pcContext = pcContext;
        }

        public async Task<IEnumerable<Customer>> GetAllCustomers()
        {
            return await _pcContext.Customers.ToListAsync();            
        }

        
        public async Task<Customer> GetCustomer(long CustomerId)
        {
            return await _pcContext.Customers.FirstOrDefaultAsync(e => e.CustomerId == CustomerId);
        }

        public async Task AddCustomer(Customer entity)
        {
            _pcContext.Customers.Add(entity);
            await _pcContext.SaveChangesAsync();
        }

        public async Task DeleteCustomer(Customer customer)
        {
            _pcContext.Customers.Remove(customer);
            await _pcContext.SaveChangesAsync();
        }

        public async Task UpdateCustomer(Customer customer, Customer entity)
        {
            customer.CustomerName = entity.CustomerName;
            customer.DateOfBirth = entity.DateOfBirth;
            customer.PhoneNumber = entity.PhoneNumber;
            customer.CustomerEmailId = entity.CustomerEmailId;

            await _pcContext.SaveChangesAsync();
        }
    }
}
