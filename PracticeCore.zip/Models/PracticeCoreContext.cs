﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PracticeCore.Models
{
    public class PracticeCoreContext : DbContext
    {
        public PracticeCoreContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<Customer> Customers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>().HasData(new Customer
            {
                CustomerId = 1,
                CustomerName = "C1",
                DateOfBirth = new DateTime(1979, 04, 25),
                PhoneNumber = "999-888-7777",
                CustomerEmailId = "c1@gmail.com"
            }, new Customer
            {
                CustomerId = 1,
                CustomerName = "C2",
                DateOfBirth = new DateTime(1977, 08, 13),
                PhoneNumber = "999-866-9090",
                CustomerEmailId = "c2@gmail.com"
            });
        }
    }    
}
