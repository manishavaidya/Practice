﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PracticeCore.Models.Repository
{
    public interface ICustomerRepository<Customer>
    {
        Task<IEnumerable<Customer>> GetAllCustomers();
        Task<Customer> GetCustomer(long CustomerId);
        Task AddCustomer(Customer customer);
        Task UpdateCustomer(Customer dbCustomer, Customer customer);
        Task DeleteCustomer(Customer customer);
    }
}
